#ifndef HW10_CALCULATOR_H
#define HW10_CALCULATOR_H


class calculator {
public:
    calculator();
    ~calculator() = default;
    static void calculate();
};


#endif //HW10_CALCULATOR_H
