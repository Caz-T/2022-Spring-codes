#include "calculator.h"
int main()
{
    calculator a;
    return 0;
}
